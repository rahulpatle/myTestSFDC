({
    doInit : function(component, event, helper) {
        var action = component.get("c.parseJSONData");
        action.setCallback(this,function(response){
            var state = response.getState();
            if(state === 'SUCCESS'){
                alert('Records retrived successfully'); // Records retrived via given url
                var externalData = response.getReturnValue();
                component.set("v.records",JSON.parse(externalData));
                component.set("v.totalRowCount",JSON.parse(externalData).length);
            }else{
                alert('Failed'+ response.getErrorMessage());
                
            }
        });
        $A.enqueueAction(action); 
    },
    add : function(component, event, helper) {
        var data = component.get("v.records");
        var id = 1;
        var incrementedID = id + 1;
        if(data.creditorName == null || data.creditorName == 'Undefined'){
            alert('Please Enter Bank/Creditor Name');
            return ;
        }
        var addRec = {    'id' : incrementedID ,'creditorName' : data.creditorName ,'firstName' : data.firstName,'lastName': data.lastName,'minPaymentPercentage' : data.minPaymentPercentage,'balance' : data.balance};
        var existingRecords = component.get("v.records");
        existingRecords.push(addRec);
        component.set("v.records", existingRecords);
        var totalRowCount = component.get("v.totalRowCount");
        var finalVal = totalRowCount + 1;
        component.set("v.totalRowCount",finalVal);
    },
    remove : function(component, event, helper) {
        
        var existingRecords = component.get("v.records");
        existingRecords.splice(-1, 1);
        component.set("v.records", existingRecords);
        var totalRowCount = component.get("v.totalRowCount");
        var finalVal = totalRowCount - 1;
        component.set("v.totalRowCount",finalVal);
    },
    
    handleSelectAll: function(component, event, helper) {
        helper.handleSelectAll(component, event, helper);
    },
    handleCheckData: function(component, event, helper) {
        helper.handleCheckData(component, event, helper);
    }
})