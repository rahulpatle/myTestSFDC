({
    handleSelectAll: function(component, event, helper) {
        var checkRowCount = 0;
        var getID = component.get("v.records");
        var checkvalue = component.find("selectAll").get("v.value");        
        var checkData = component.find("checkData"); 
        if(checkvalue == true){
            for(var i=0; i<checkData.length; i++){
                checkData[i].set("v.value",true);
                checkRowCount ++ ; 
                component.set("v.checkRowCount",checkRowCount);
                
            }
        }
        else{ 
            for(var i=0; i<checkData.length; i++){
                checkData[i].set("v.value",false);
                checkRowCount = 0 ; 
                component.set("v.checkRowCount",checkRowCount);
                
            }
        }
        component.set("v.checkRowCount",checkRowCount);
               this.calculateSum(component, event, helper);

    },
    handleCheckData: function(component, event, helper) {
        var checkRowCount = component.get("v.checkRowCount");
            
        var checkData = event.getSource().get("v.value"); 
        if(checkData){
                    checkRowCount ++;
            component.set("v.checkRowCount",checkRowCount);
            
        }
        else{ 
          
            checkRowCount --;
            component.set("v.checkRowCount",checkRowCount);
            
        }
       this.calculateSum(component, event, helper);
    },
    calculateSum: function(component, event, helper) {
        var totalSum = component.get("v.totalSum");
        var selectedRec = [];
        var checkvalue = component.find("checkData");
         
        if(!Array.isArray(checkvalue)){
            if (checkvalue.get("v.value") == true) {
                selectedRec.push(checkvalue.get("v.text"));
                
            }
        }else{
            for (var i = 0; i < checkvalue.length; i++) {
                if (checkvalue[i].get("v.value") == true) {
                   selectedRec.push(checkvalue[i].get("v.text"));
                     
                }
            }
        }
        console.log('selectedRec-' + selectedRec);
         totalSum =   selectedRec.reduce((a, b) => a + b, 0);
        component.set("v.totalSum",totalSum);
    }
   
})